board=['-','-','-','-','-','-','-','-','-']
odd_num=[99,99,99,99,99]
even_num=[99,99,99,99,99]
win=[0,0,0,0,0,0,0,0,0]
OC=0
EC=0
def showboard():
    print(board[0],'|',board[1],'|',board[2])
    print('---------')
    print(board[3],'|',board[4],'|',board[5])
    print('---------')
    print(board[6],'|',board[7],'|',board[8])
    print('---------')
showboard()
Rounds=1

def write(a,b):
    board[a]=b
    showboard()
while True:
    if Rounds%2==1:
        print('player 1:')
        a=int(input('Enter Place: '))
        while a<0 or a>8:
            print('please, choose a number from 0 to 8')
            a=int(input('Enter place: '))
        while board[a]==0 or board[a]==1 or board[a]==2 or board[a]==3 or board[a]==4 or board[a]==5 or board[a]==6 or board[a]==7 or board[a]==8:
            print('This place have takken!')
            a=int(input('Enter place: '))
        b=int(input('Enter an odd number from 0 to 9: '))
        while b<0 or b>9 or b%2==0:
            print('can`t use this number')
            b=int(input('Enter an odd number from 0 to 9: '))
        i=0
        while i<5:
            if odd_num[i]==b:
                print('This Number is Already Taken')
                b=int(input('Enter an odd number from 0 to 9: '))
                i=0
            else:
                i+=1
        odd_num[OC]=b
        OC+=1
        write(a,b)
        win[a]=b
        if (win[0]+win[1]+win[2])==15 or(win[3]+win[4]+win[5])==15 or(win[6]+win[7]+win[8])==15 or(win[0]+win[3]+win[6])==15 or(win[1]+win[4]+win[7])==15 or(win[2]+win[5]+win[8])==15 or(win[2]+win[4]+win[6])==15 or(win[0]+win[4]+win[8])==15:
             print('Player 1 Have Won')
             break
    else:
        print('player 2:')
        a=int(input('Enter place: '))
        while a<0 or a>8:
            print('please, choose a number from 0 to 8')
            a=int(input('Enter place: '))
        while board[a]==0 or board[a]==1 or board[a]==2 or board[a]==3 or board[a]==4 or board[a]==5 or board[a]==6 or board[a]==7 or board[a]==8:
            print('This place have takken!')
            a=int(input('Enter place: '))
        b=int(input('Enter an even number from 0 to 9: '))
        while b<0 or b>9 or b%2==1:
            print('can`t use this number')
            b=int(input('Enter an even number from 0 to 9: '))
        i=0
        while i<5:
            if even_num[i]==b:
                print('This Number is Already Taken')
                b=int(input('Enter an even number from 0 to 9: '))
                i=0
            else:
                i+=1
        even_num[EC]=b
        EC+=1
        write(a,b)
        win[a]=b
        if (win[0]+win[1]+win[2])==15 or(win[3]+win[4]+win[5])==15 or(win[6]+win[7]+win[8])==15 or(win[0]+win[3]+win[6])==15 or(win[1]+win[4]+win[7])==15 or(win[2]+win[5]+win[8])==15 or(win[2]+win[4]+win[6])==15 or(win[0]+win[4]+win[8])==15:
              print('Player 2 Have Won')
              break
    Rounds+=1
